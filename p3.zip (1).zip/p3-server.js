/*
    CIT 281 Project 3
    Name: Mallory Thompson
*/
const fs = require('fs');
const fastify = require('fastify')();

const { coinCount } = require('./p3-module');

fastify.get('/', (req, res) => {
  fs.readFile(__dirname + '/index.html', (err, data) => {
    if (err) {
      res.code(500).send('Error loading index.html');
    } else {
      res.header('Content-Type', 'text/html').send(data);
    }
  });
});

fastify.get('/coin', (req, res) => {
  const { denom = 0, count = 0 } = req.query;
  const coins = { denom: parseInt(denom), count: parseInt(count) };
  const coinValue = coinCount(coins);
  const html = `<h2>Value of ${count} of ${denom} is ${coinValue}</h2><br /><a href="/">Home</a>`;
  res.header('Content-Type', 'text/html').send(html);
});

fastify.get('/coins', (req, res) => {
  const { option } = req.query;
  let coinValue = 0;

  switch (option) {
    case '1':
      coinValue = coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 });
      break;
    case '2':
      const coins = [1, 5, 10, 25, 50];
      coinValue = coinCount(...coins);
      break;
    case '3':
      const coins2 = { denom: 5, count: 3 };
      coinValue = coinCount(coins2);
      break;
    default:
      break;
  }

  const html = `<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`;
  res.header('Content-Type', 'text/html').send(html);
});

fastify.listen(8080, 'localhost', (err) => {
  if (err) {
    console.error(err);
  } else {
    console.log(`Server is listening on 8080`);
  }
});
