const fastify = require("fastify")();
const {getQuestions, getAnswers, getQuestionsAnswers, getQuestion, getAnswer, getQuestionAnswer} = require('./p4-module.js');

fastify.get("/cit/question", function (request, reply) {
const response = {
    "error": "",
    "statusCode": 200,
    "questions": [
        "Q1",
        "Q2",
        "Q3"
    ]
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

fastify.get("/cit/answer", function (request, reply) {
const response = {
    "error": "",
    "statusCode": 200,
    "answers": [
        "A1",
        "A2",
        "A3"
    ]
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

fastify.get("/cit/questionanswer", function (request, reply) {
const response = {
    "error": "",
    "statusCode": 200,
    "questions_answers": [
        {
            "question": "Q1",
            "answer": "A1"
        },
        {
            "question": "Q2",
            "answer": "A2"
        },
        {
            "question": "Q3",
            "answer": "A3"
        }
    ]
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

//http://localhost:8080/cit/question/:number?number=2
fastify.get("/cit/question/:number", function (request, reply) {
console.log(request.query);
const { number } = request.query;
const questionNumber = getQuestion(number);
const response = {
    "error": "",
    "statusCode": 200,
    "question": "Q1",
    "number": 1
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

//http://localhost:8080/cit/answer/:number?number=1
fastify.get("/cit/answer/:number", function (request, reply) {
console.log(request.query);
const response = {
    "error": "",
    "statusCode": 200,
    "answer": "A2",
    "number": 2
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

//http://localhost:8080/cit/questionanswer/:number?number=3
fastify.get("/cit/questionanswer/:number", function (request, reply) {
console.log(request.query);
const response = {
    "error": "",
    "statusCode": 200,
    "question": "Q3",
    "answer": "A3",
    "number": 3
}
reply
.code(200)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

fastify.get("*", function (request, reply) {
const response = {
    "error": "Route not found",
    "statusCode": 404
}
reply
.code(404)
.header("Content-Type", "application/json; charset=utf-8")
.send(response);
});

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, function (err, address) {
if (err) {
console.log(err);
process.exit(1);
} console.log('Server listenIP on ${address}');
})